﻿using GameStore.Attributes;
using GameStore.Settings;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace GameStore.Viewmodels
{
    public class CreateGameFormViewModel:BaseGameFormViewModel
    {

        [AllowedExtension(FileSettings.AllowedExtensions), MaxFileSize(FileSettings.MaxFileSizeInBytes)]
        public IFormFile Cover { get; set; } = default!; 
    }
}
