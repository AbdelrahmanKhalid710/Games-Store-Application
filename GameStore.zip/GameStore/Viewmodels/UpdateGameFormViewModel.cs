﻿using GameStore.Attributes;
using GameStore.Settings;

namespace GameStore.Viewmodels
{
    public class UpdateGameFormViewModel:BaseGameFormViewModel
    {
        public int Id { get; set; }
        public string? CurrentCover { get; set; }
        [AllowedExtension(FileSettings.AllowedExtensions), MaxFileSize(FileSettings.MaxFileSizeInBytes)]
        public IFormFile? Cover { get; set; }
    }
}
