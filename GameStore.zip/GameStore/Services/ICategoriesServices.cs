﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace GameStore.Services
{
    public interface ICategoriesServices
    {
        IEnumerable<SelectListItem> GetCategoriesList();
    }
}
