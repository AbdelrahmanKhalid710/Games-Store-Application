﻿using GameStore.Models;
using GameStore.Viewmodels;

namespace GameStore.Services
{
    public interface IGameServices
    {
        IEnumerable<Game> GetAll();
        Game? GetGameById(int id);
        Task Create(CreateGameFormViewModel game);
        Task<Game?> Update(UpdateGameFormViewModel game);
        bool Delete(int id);
    }
}
