﻿using GameStore.Data;
using GameStore.Services;
using GameStore.Viewmodels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GameStore.Controllers
{
    public class GamesController : Controller
    {
        private readonly ICategoriesServices _categoriesServices;
        private readonly IDevicesService _devicesServices;
        private readonly IGameServices _gameServices;
        public GamesController(ApplicationDbContext context, ICategoriesServices categoriesServices, IDevicesService devicesServices, IGameServices gameServices)
        {
            _categoriesServices = categoriesServices;
            _devicesServices = devicesServices;
            _gameServices = gameServices;
        }

        public IActionResult Index()
        {
            var games = _gameServices.GetAll();
            return View(games);
        }
        public IActionResult Details(int id)
        {
            var game = _gameServices.GetGameById(id);
            if(game == null)
                return NotFound();

            return View(game);
        }
        [HttpGet]
        public IActionResult Create() 
        {

            CreateGameFormViewModel viewModel = new()
            {

                Categories = _categoriesServices.GetCategoriesList(),
                Devices =  _devicesServices.GetDevicesList(),
            }; 
            return View(viewModel);
        }

        /*Add Game Post Endpoint*/
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateGameFormViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                viewModel.Categories = _categoriesServices.GetCategoriesList();
                viewModel.Devices = _devicesServices.GetDevicesList();
                return View(viewModel);
            }
             await  _gameServices.Create(viewModel);
            return RedirectToAction(nameof(Index));
        }
        [HttpGet]
        public IActionResult Update(int id)
        {
            var game = _gameServices.GetGameById(id);   
            if(game == null)
            return NotFound();

            UpdateGameFormViewModel viewModel = new()
            {
                Id = id,
                Name = game.Name,
                Description = game.Description,
                CategoryId = game.CategoryId,
                SelectedDevices = game.GameDevices.Select(d => d.DeviceId).ToList(),
                Categories = _categoriesServices.GetCategoriesList(),
                Devices = _devicesServices.GetDevicesList(),
                CurrentCover = game.Cover

            };
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(UpdateGameFormViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                viewModel.Categories = _categoriesServices.GetCategoriesList();
                viewModel.Devices = _devicesServices.GetDevicesList();
                return View(viewModel);
            }
            var game = await _gameServices.Update(viewModel);
            if (game == null)
                return BadRequest();
            return RedirectToAction(nameof(Index));
        }
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var isDeleted = _gameServices.Delete(id);
            
            return isDeleted ? Ok() : BadRequest();
        }
    }
}
